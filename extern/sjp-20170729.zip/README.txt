
Słownik SJP.PL - wersja do gier słownych

Słownik udostępniany na licencjach GPL oraz
Creative Commons ShareAlike

https://sjp.pl

